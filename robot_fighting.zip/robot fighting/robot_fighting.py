import random
from accessible_output2.outputs.auto import Auto
import pygame

output = Auto()
pygame.mixer.init()

laser_sound = pygame.mixer.Sound("laser.wav")
nitro_sound = pygame.mixer.Sound("nitro.wav")
hit_sound = pygame.mixer.Sound("hit.wav")
shield_sound = pygame.mixer.Sound("shield.wav")
heal_sound = pygame.mixer.Sound("heal.wav")

class Weapon:
    def __init__(self, name, damage_range):
        self.name = name
        self.damage_range = damage_range

    def fire(self):
        return random.randint(*self.damage_range)

class Robot:
    def __init__(self, name, hp):
        self.name = name
        self.hp = hp
        self.max_hp = hp
        self.shield_available = True
        self.healing = False
        self.stunned = 0
        self.weapons = {
            'left_laser': Weapon("Left Laser", (5, 10)),
            'right_laser': Weapon("Right Laser", (5, 10)),
            'nitro_cannon': Weapon("Nitro Cannon", (15, 25))
        }

    def take_damage(self, damage):
        self.hp -= damage
        if self.hp < 0:
            self.hp = 0

    def use_shield(self):
        if self.shield_available:
            self.shield_available = False
            self.stunned = 1
            shield_sound.play()
            return True
        return False

    def heal(self):
        if not self.healing:
            self.healing = True
            self.stunned = 3
            heal_amount = random.randint(20, 30)
            self.hp = min(self.hp + heal_amount, self.max_hp)
            heal_sound.play()
            return heal_amount
        return 0

    def update(self):
        if self.stunned > 0:
            self.stunned -= 1
        if self.stunned == 0:
            self.healing = False

class Player(Robot):
    def __init__(self):
        super().__init__("Player", 100)

class Enemy(Robot):
    def __init__(self):
        super().__init__("Enemy Robot", 100)

player = Player()
enemy = Enemy()

def speak(text):
    output.speak(text)

def player_turn():
    while True:
        speak("Your turn. Choose an action: 1-Left Laser, 2-Right Laser, 3-Nitro Cannon, 4-Shield, 5-Heal, 6-Check Status")
        choice = input("Enter your choice (1-6): ")
        if choice == '1':
            return use_weapon('left_laser')
        elif choice == '2':
            return use_weapon('right_laser')
        elif choice == '3':
            return use_weapon('nitro_cannon')
        elif choice == '4':
            return use_shield()
        elif choice == '5':
            return use_heal()
        elif choice == '6':
            check_status()
        else:
            speak("Invalid choice. Please try again.")

def use_weapon(weapon_name):
    if player.stunned > 0:
        speak(f"You are stunned for {player.stunned} more turns and cannot use weapons.")
        return False
    weapon = player.weapons[weapon_name]
    damage = weapon.fire()
    enemy.take_damage(damage)
    if weapon_name.endswith('laser'):
        laser_sound.play()
    else:
        nitro_sound.play()
    speak(f"You fired {weapon.name}! Enemy took {damage} damage.")
    return True

def use_shield():
    if player.stunned > 0:
        speak(f"You are stunned for {player.stunned} more turns and cannot use shield.")
        return False
    if player.use_shield():
        speak("Shield activated! You are protected for this turn but stunned for the next turn.")
        return True
    else:
        speak("Shield has already been used.")
        return False

def use_heal():
    if player.stunned > 0:
        speak(f"You are stunned for {player.stunned} more turns and cannot heal.")
        return False
    heal_amount = player.heal()
    if heal_amount > 0:
        speak(f"You started healing. Recovered {heal_amount} HP. You are stunned for 3 turns.")
        return True
    else:
        speak("You are already healing.")
        return False

def check_status():
    speak(f"Your HP: {player.hp}/{player.max_hp}. Shield available: {'Yes' if player.shield_available else 'No'}. Stunned: {player.stunned} turns.")
    speak(f"Enemy HP: {enemy.hp}/{enemy.max_hp}")

def enemy_turn():
    if enemy.stunned > 0:
        speak(f"Enemy is stunned for {enemy.stunned} more turns.")
        return

    action = random.choice(['weapon', 'weapon', 'weapon', 'shield', 'heal'])
    if action == 'weapon':
        weapon = random.choice(list(enemy.weapons.values()))
        damage = weapon.fire()
        if player.shield_available:
            speak("Enemy attacks! But your shield protects you.")
            player.use_shield()
        else:
            player.take_damage(damage)
            hit_sound.play()
            speak(f"Enemy fires {weapon.name}! You took {damage} damage.")
    elif action == 'shield':
        if enemy.use_shield():
            speak("Enemy activated their shield!")
        else:
            speak("Enemy tried to use shield, but it was already used.")
    elif action == 'heal':
        heal_amount = enemy.heal()
        if heal_amount > 0:
            speak(f"Enemy started healing. Recovered {heal_amount} HP. They are stunned for 3 turns.")
        else:
            speak("Enemy tried to heal, but they were already healing.")

def game_loop():
    speak("Welcome to Robot Battle! This is a turn-based game. You'll choose your action each turn.")
    
    while player.hp > 0 and enemy.hp > 0:
        player.update()
        enemy.update()
        
        if player_turn():
            if enemy.hp <= 0:
                speak("Congratulations! You defeated the enemy robot!")
                break
            enemy_turn()
            if player.hp <= 0:
                speak("Game over. Your robot was destroyed.")
                break

    speak("Press Enter to exit.")
    input()

if __name__ == "__main__":
    game_loop()